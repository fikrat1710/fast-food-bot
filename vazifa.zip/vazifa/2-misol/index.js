const fs=require('fs');
fs.writeFileSync("result.txt","Hello my name is Jaihun")
const readFile=fs.readFileSync("result.txt","utf8")
console.log(readFile);
