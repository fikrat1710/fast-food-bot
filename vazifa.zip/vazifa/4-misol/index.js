const fs = require('fs');
const path = require('path');

const structure = {
    "html": ["index.html"],
    "static": ["script.js", "script.ts", "style.css"],
    "": ["go.mod", "go.sum", "golang-todo-app", "main.go", "README.md", "tsconfig.json"]
};

const createStructure = (basePath, structure) => {
    Object.entries(structure).forEach(([folder, files]) => {
        const folderPath = path.join(basePath, folder);

        if (folder && !fs.existsSync(folderPath)) {
            fs.mkdirSync(folderPath, { recursive: true });
            console.log(`📂 Created folder: ${folderPath}`);
        }

        files.forEach(file => {
            const filePath = path.join(folderPath, file);
            if (!fs.existsSync(filePath)) {
                fs.writeFileSync(filePath, "");
                console.log(`📄 Created file: ${filePath}`);
            }
        });
    });
};

const projectPath = path.join(__dirname, "myProject"); 
if (!fs.existsSync(projectPath)) {
    fs.mkdirSync(projectPath);
}
createStructure(projectPath, structure);

console.log("\n Tuzilma muvaffaqiyatli yaratildi!");
