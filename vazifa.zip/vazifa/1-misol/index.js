const {plus,minus}=require('./other.js')
plus(1,2)
minus(1,2)  