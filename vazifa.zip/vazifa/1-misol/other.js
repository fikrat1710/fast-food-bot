function plus(a, b) {
    console.log(a+b)    
}
function minus(a, b) {
    console.log(a-b)    
}
module.exports = {plus, minus}
