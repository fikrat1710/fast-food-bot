const fs= require("fs")
const numbers  =Array.from({length:10},()=>Math.floor(Math.random()*100))
const buffer=Buffer.from(numbers.join(" "))
fs.writeFileSync("random.txt",buffer)
console.log("File yozildi",numbers);
const readBuffer=fs.readFileSync("random.txt")
console.log("fayldan o'qildi",readBuffer.toString());

