const fs = require('fs');
const path = require('path');

const folders = [
  'tests',
  '__mocks__',
  '__tests__',
  'coverage',
  'dist',
  'docs',
  'api',
  'public',
  'scripts',
  'deployment',
  'src'
];

folders.forEach(folder => {
  const dir = path.join(__dirname, folder);
  if (!fs.existsSync(dir)){
    fs.mkdirSync(dir, { recursive: true });
    console.log(`Papka yaratildi: ${folder}`);
  } else {
    console.log(`Papka allaqachon mavjud: ${folder}`);
  }
});

const files = [
  { name: '.gitignore', content: 'node_modules/\ncoverage/\ndist/\n.env' },
  { name: 'index.js', content: 'console.log("Hello, Node.js!");' }
];

files.forEach(file => {
  const filePath = path.join(__dirname, file.name);
  if (!fs.existsSync(filePath)){
    fs.writeFileSync(filePath, file.content);
    console.log(`Fayl yaratildi: ${file.name}`);
  } else {
    console.log(`Fayl allaqachon mavjud: ${file.name}`);
  }
});

console.log('Loyiha strukturasi muvaffaqiyatli yaratildi.');